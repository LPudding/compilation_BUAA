#pragma once
void printSet(set<string> set);

void printMap(map<string, int> mmap);

string lowerS(string str);