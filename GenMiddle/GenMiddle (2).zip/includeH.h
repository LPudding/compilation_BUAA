#pragma once


#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<map>
#include<set>
#include<list>
#include<cstdio>
#include<ctype.h>
#include<cstdlib>
#include<algorithm>
#include<string.h>
#include<assert.h>
#include <regex>
#include"mid.h"
#include"error.h"
#include"grama.h"
#include"lexicalAna.h"
#include"opt.h"
#include"translate.h"
#include"tool.h"

using namespace std;
extern FILE* fp, * fl, * fc, * fe;
#pragma warning(disable:4996)
extern bool isError;
