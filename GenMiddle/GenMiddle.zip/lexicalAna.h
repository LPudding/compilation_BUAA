#pragma once
#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<iomanip>
using namespace std;

bool isNumStr(string str,int& val);

bool isVarStr(string str);

void clearToken();

void getChar();

void addToken();

void finishToken();

int isunderline(char c);

void back();

int matcher();

void newLine();

bool isChar(char ch);

bool isStr(char ch);

int getsym();

int watch();

int watchTwice();

int watchThrice();

void printWord(int id);