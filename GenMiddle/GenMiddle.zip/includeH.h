#pragma once


#include<iostream>
#include<string>
#include<vector>
#include<fstream>
#include<cstdio>
#include<ctype.h>
#include<cstdlib>
#include<algorithm>
#include<string.h>
#include"mid.h"
#include"error.h"
#include"GenMiddle.h"
#include"grama.h"
#include"lexicalAna.h"
#include"opt.h"
#include"translate.h"

using namespace std;

#pragma warning(disable:4996)